import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { BookOpen, Bus, Calendar, Search, UtensilsCrossed, MessageSquare, LayoutGrid, Shield, X, Home, LogOut } from "lucide-react";
import { useAdminAuth } from "@/hooks/useAdminAuth";

const publicNavItems = [
  { to: "/", label: "Home", icon: Home },
  { to: "/notes", label: "Notes", icon: BookOpen },
  { to: "/bus-timings", label: "Bus Timings", icon: Bus },
  { to: "/events", label: "Events", icon: Calendar },
  { to: "/lost-found", label: "Lost & Found", icon: Search },
  { to: "/canteen", label: "Canteen Menu", icon: UtensilsCrossed },
  { to: "/contact", label: "Contact Admin", icon: MessageSquare },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { isAdmin, signOut } = useAdminAuth();

  const navItems = [
    ...publicNavItems,
    ...(isAdmin ? [{ to: "/admin", label: "Admin Panel", icon: Shield }] : [{ to: "/admin-login", label: "Admin Login", icon: Shield }]),
  ];

  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex flex-col w-56 border-r border-border bg-background fixed h-full z-30">
        <div className="p-4 border-b border-border">
          <Link to="/">
            <h1 className="text-lg font-bold tracking-tight font-display">Campus Connect</h1>
            <p className="text-xs text-muted-foreground font-mono mt-0.5">Sri Vasavi Engineering College</p>
          </Link>
        </div>
        <nav className="flex-1 py-2">
          {navItems.map((item) => {
            const active = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                  active
                    ? "text-primary font-medium bg-accent"
                    : "text-foreground hover:bg-accent"
                }`}
              >
                <item.icon size={18} strokeWidth={active ? 2.5 : 1.5} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-border">
          {isAdmin && (
            <button onClick={signOut} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground mb-2 transition-colors">
              <LogOut size={13} />
              Sign out
            </button>
          )}
          <p className="text-xs text-muted-foreground font-mono">© 2026 Sri Vasavi Engg.</p>
        </div>
      </aside>

      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-40 bg-background border-b border-border flex items-center justify-between px-4 py-3">
        <Link to="/">
          <h1 className="text-base font-bold font-display">Campus Connect</h1>
        </Link>
        <button
          onClick={() => setMobileOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 border border-border text-sm font-medium"
        >
          <LayoutGrid size={14} />
          Menu
        </button>
      </div>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-foreground/20" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-64 bg-background border-r border-border flex flex-col">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <h1 className="text-base font-bold font-display">Campus Connect</h1>
              <button onClick={() => setMobileOpen(false)}>
                <X size={20} />
              </button>
            </div>
            <nav className="flex-1 py-2">
              {navItems.map((item) => {
                const active = location.pathname === item.to;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 text-sm transition-colors ${
                      active
                        ? "text-primary font-medium bg-accent"
                        : "text-foreground hover:bg-accent"
                    }`}
                  >
                    <item.icon size={18} strokeWidth={active ? 2.5 : 1.5} />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
            {isAdmin && (
              <div className="p-4 border-t border-border">
                <button onClick={signOut} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors">
                  <LogOut size={13} />
                  Sign out
                </button>
              </div>
            )}
          </aside>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 md:ml-56 mt-14 md:mt-0">
        <div className="p-4 md:p-8 max-w-5xl">
          {children}
        </div>
      </main>
    </div>
  );
}
