import { useState } from "react";
import { Send, CheckCircle } from "lucide-react";

const BRANCHES = ["CSE", "ECE", "EEE", "Mechanical", "Civil"];

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", rollNumber: "", branch: "CSE", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.message.trim()) return;
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({ name: "", rollNumber: "", branch: "CSE", message: "" });
    }, 3000);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold font-display mb-1">Contact Admin</h2>
      <p className="text-sm text-muted-foreground mb-6">Send a query or message to the college administration.</p>

      {submitted ? (
        <div className="border border-border bg-card p-8 text-center max-w-lg">
          <CheckCircle size={32} className="mx-auto mb-3 text-success" />
          <p className="font-medium text-sm">Message sent successfully!</p>
          <p className="text-xs text-muted-foreground mt-1">An admin will review your query shortly.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="border border-border bg-card p-5 max-w-lg space-y-3">
          <div>
            <label className="text-xs font-medium block mb-1">Name *</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium block mb-1">Roll Number</label>
              <input value={form.rollNumber} onChange={(e) => setForm({ ...form, rollNumber: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Branch</label>
              <select value={form.branch} onChange={(e) => setForm({ ...form, branch: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary">
                {BRANCHES.map((b) => <option key={b}>{b}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs font-medium block mb-1">Message *</label>
            <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={4} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary resize-none" required />
          </div>
          <button type="submit" className="flex items-center gap-2 px-5 py-2 text-sm font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity">
            <Send size={14} />
            Send Message
          </button>
        </form>
      )}
    </div>
  );
}
