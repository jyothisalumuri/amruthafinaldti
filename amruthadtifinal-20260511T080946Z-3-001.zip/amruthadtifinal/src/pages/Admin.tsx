import { useState } from "react";
import { BookOpen, Bus, Calendar, UtensilsCrossed, Search, MessageSquare } from "lucide-react";

type Tab = "notes" | "bus" | "events" | "canteen" | "lostfound" | "messages";

const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "notes", label: "Notes", icon: BookOpen },
  { id: "bus", label: "Bus", icon: Bus },
  { id: "events", label: "Events", icon: Calendar },
  { id: "canteen", label: "Canteen", icon: UtensilsCrossed },
  { id: "lostfound", label: "Lost & Found", icon: Search },
  { id: "messages", label: "Messages", icon: MessageSquare },
];

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<Tab>("notes");

  return (
    <div>
      <h2 className="text-2xl font-bold font-display mb-1">Admin Panel</h2>
      <p className="text-sm text-muted-foreground mb-6">Manage all campus information from one place.</p>

      <div className="flex flex-wrap gap-1 mb-6 border-b border-border">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium transition-colors border-b-2 ${
              activeTab === tab.id
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "notes" && <AdminNotes />}
      {activeTab === "bus" && <AdminBus />}
      {activeTab === "events" && <AdminEvents />}
      {activeTab === "canteen" && <AdminCanteen />}
      {activeTab === "lostfound" && <AdminLostFound />}
      {activeTab === "messages" && <AdminMessages />}
    </div>
  );
}

function AdminNotes() {
  return (
    <div className="border border-border bg-card p-5 space-y-3">
      <h3 className="font-bold text-sm font-display">Upload Notes</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input placeholder="Subject name" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <select className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary">
          <option>CSE</option><option>ECE</option><option>EEE</option><option>Mechanical</option><option>Civil</option>
        </select>
        <select className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary">
          <option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option>
        </select>
        <input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx" className="px-3 py-2 text-sm bg-background border border-border" />
      </div>
      <button className="px-5 py-2 text-sm font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity">Upload Note</button>
      <p className="text-xs text-muted-foreground">Note: Connect a backend to persist uploads.</p>
    </div>
  );
}

function AdminBus() {
  return (
    <div className="border border-border bg-card p-5 space-y-3">
      <h3 className="font-bold text-sm font-display">Add Bus Route</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input placeholder="Route name" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input placeholder="Bus number" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input type="time" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input placeholder="Driver name" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input placeholder="Contact number" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
      </div>
      <button className="px-5 py-2 text-sm font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity">Add Route</button>
    </div>
  );
}

function AdminEvents() {
  return (
    <div className="border border-border bg-card p-5 space-y-3">
      <h3 className="font-bold text-sm font-display">Post Event</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input placeholder="Event name" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input type="date" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input placeholder="Location" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input placeholder="Eligible (e.g. CSE 3rd Year)" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input placeholder="Registration link (optional)" className="sm:col-span-2 px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
      </div>
      <textarea placeholder="Event description" rows={3} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
      <button className="px-5 py-2 text-sm font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity">Post Event</button>
    </div>
  );
}

function AdminCanteen() {
  return (
    <div className="border border-border bg-card p-5 space-y-3">
      <h3 className="font-bold text-sm font-display">Add Menu Item</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <input placeholder="Item name" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <input type="number" placeholder="Price (₹)" className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
        <select className="px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary">
          <option>Breakfast</option><option>Snacks</option><option>Meals</option><option>Drinks</option>
        </select>
      </div>
      <button className="px-5 py-2 text-sm font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity">Add Item</button>
    </div>
  );
}

function AdminLostFound() {
  return (
    <div className="border border-border bg-card p-5">
      <h3 className="font-bold text-sm font-display mb-3">Lost & Found Reports</h3>
      <p className="text-sm text-muted-foreground">Connect a backend to view and manage all lost & found reports here.</p>
    </div>
  );
}

function AdminMessages() {
  const mockMessages = [
    { id: 1, name: "Priya K.", roll: "20B01A0512", branch: "CSE", message: "Can you upload OS Unit 3 notes?", date: "2026-03-09" },
    { id: 2, name: "Rahul M.", roll: "20B01A0234", branch: "ECE", message: "Bus SV-02 was late today by 30 minutes.", date: "2026-03-08" },
    { id: 3, name: "Sneha R.", roll: "20B01A0378", branch: "EEE", message: "Please update the canteen menu with new items.", date: "2026-03-07" },
  ];

  return (
    <div className="space-y-3">
      <h3 className="font-bold text-sm font-display">Student Messages</h3>
      {mockMessages.map((msg) => (
        <div key={msg.id} className="border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm">{msg.name}</span>
            <span className="text-xs font-mono text-muted-foreground">{msg.roll} · {msg.branch}</span>
            <span className="text-xs font-mono text-muted-foreground ml-auto">{msg.date}</span>
          </div>
          <p className="text-sm text-muted-foreground">{msg.message}</p>
        </div>
      ))}
    </div>
  );
}
