import { Calendar, MapPin, ExternalLink } from "lucide-react";

type Event = {
  id: number;
  name: string;
  date: string;
  location: string;
  eligible: string;
  registrationLink?: string;
  description: string;
};

const mockEvents: Event[] = [
  { id: 1, name: "TechFest 2026", date: "2026-03-25", location: "Main Auditorium", eligible: "All branches, All years", registrationLink: "#", description: "Annual technical festival with coding competitions, robotics, and paper presentations." },
  { id: 2, name: "Campus Recruitment Drive", date: "2026-04-05", location: "Placement Cell", eligible: "CSE, ECE — 4th Year", description: "On-campus recruitment by TCS, Infosys, and Wipro." },
  { id: 3, name: "Sports Day", date: "2026-04-12", location: "College Ground", eligible: "All branches, All years", description: "Inter-branch sports competitions including cricket, volleyball, and athletics." },
  { id: 4, name: "Workshop: IoT & Embedded Systems", date: "2026-03-30", location: "ECE Lab", eligible: "ECE, EEE — 2nd & 3rd Year", registrationLink: "#", description: "Hands-on workshop on IoT prototyping with Arduino and Raspberry Pi." },
  { id: 5, name: "Cultural Night", date: "2026-04-20", location: "Open Air Theatre", eligible: "All branches, All years", description: "Annual cultural evening with dance, music, and drama performances." },
  { id: 6, name: "Guest Lecture: AI in Healthcare", date: "2026-04-02", location: "CSE Seminar Hall", eligible: "CSE — 3rd & 4th Year", description: "Talk by Dr. Sunita from IIT Hyderabad on applications of AI in modern healthcare." },
];

export default function EventsPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold font-display mb-1">Upcoming Events</h2>
      <p className="text-sm text-muted-foreground mb-6">Stay updated with college events, workshops, and activities.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {mockEvents.map((event) => (
          <div key={event.id} className="border border-border bg-card p-5">
            <h3 className="font-bold text-base font-display mb-2">{event.name}</h3>
            <p className="text-sm text-muted-foreground mb-3">{event.description}</p>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex items-center gap-2">
                <Calendar size={13} className="text-muted-foreground" />
                <span>{new Date(event.date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" })}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={13} className="text-muted-foreground" />
                <span>{event.location}</span>
              </div>
              <div className="text-muted-foreground">Eligible: {event.eligible}</div>
            </div>
            {event.registrationLink && (
              <a
                href={event.registrationLink}
                className="inline-flex items-center gap-1 mt-3 px-4 py-1.5 text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
              >
                Register
                <ExternalLink size={12} />
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
