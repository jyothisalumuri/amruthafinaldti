import { useState } from "react";
import { MapPin, Clock, User } from "lucide-react";

type LostItem = {
  id: number;
  itemName: string;
  place: string;
  date: string;
  time: string;
  rollNumber: string;
  branch: string;
  type: "lost" | "found";
};

const mockItems: LostItem[] = [
  { id: 1, itemName: "Blue Backpack", place: "Library", date: "2026-03-08", time: "02:30 PM", rollNumber: "20B01A0512", branch: "CSE", type: "lost" },
  { id: 2, itemName: "Calculator (Casio fx-991)", place: "Exam Hall 3", date: "2026-03-07", time: "11:00 AM", rollNumber: "20B01A0234", branch: "ECE", type: "lost" },
  { id: 3, itemName: "ID Card", place: "Canteen", date: "2026-03-09", time: "01:00 PM", rollNumber: "20B01A0378", branch: "EEE", type: "found" },
  { id: 4, itemName: "Umbrella (Black)", place: "Main Gate", date: "2026-03-06", time: "04:30 PM", rollNumber: "20B01A0145", branch: "Mechanical", type: "found" },
];

const BRANCHES = ["CSE", "ECE", "EEE", "Mechanical", "Civil"];

export default function LostFoundPage() {
  const [items, setItems] = useState(mockItems);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ itemName: "", place: "", date: "", time: "", rollNumber: "", branch: "CSE", type: "lost" as "lost" | "found" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.itemName.trim() || !form.place.trim() || !form.rollNumber.trim()) return;
    setItems([{ ...form, id: Date.now() }, ...items]);
    setForm({ itemName: "", place: "", date: "", time: "", rollNumber: "", branch: "CSE", type: "lost" });
    setShowForm(false);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <h2 className="text-2xl font-bold font-display">Lost & Found</h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-1.5 text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
        >
          {showForm ? "Cancel" : "Report Item"}
        </button>
      </div>
      <p className="text-sm text-muted-foreground mb-6">Report or find lost items on campus.</p>

      {showForm && (
        <form onSubmit={handleSubmit} className="border border-border bg-card p-5 mb-6 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium block mb-1">Item Name *</label>
              <input value={form.itemName} onChange={(e) => setForm({ ...form, itemName: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" required />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Place *</label>
              <input value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" required />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Date</label>
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Time</label>
              <input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Roll Number *</label>
              <input value={form.rollNumber} onChange={(e) => setForm({ ...form, rollNumber: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary" required />
            </div>
            <div>
              <label className="text-xs font-medium block mb-1">Branch</label>
              <select value={form.branch} onChange={(e) => setForm({ ...form, branch: e.target.value })} className="w-full px-3 py-2 text-sm bg-background border border-border focus:outline-none focus:ring-1 focus:ring-primary">
                {BRANCHES.map((b) => <option key={b}>{b}</option>)}
              </select>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-1.5 text-sm cursor-pointer">
              <input type="radio" checked={form.type === "lost"} onChange={() => setForm({ ...form, type: "lost" })} className="accent-primary" />
              Lost
            </label>
            <label className="flex items-center gap-1.5 text-sm cursor-pointer">
              <input type="radio" checked={form.type === "found"} onChange={() => setForm({ ...form, type: "found" })} className="accent-primary" />
              Found
            </label>
          </div>
          <button type="submit" className="px-5 py-2 text-sm font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity">
            Submit Report
          </button>
        </form>
      )}

      <div className="space-y-3">
        {items.map((item) => (
          <div key={item.id} className="border border-border bg-card p-4 flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className={`px-2 py-0.5 text-[10px] font-mono font-medium uppercase ${item.type === "lost" ? "bg-destructive text-destructive-foreground" : "bg-success text-success-foreground"}`}>
                  {item.type}
                </span>
                <span className="font-medium text-sm">{item.itemName}</span>
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-mono text-muted-foreground">
                <span className="flex items-center gap-1"><MapPin size={12} />{item.place}</span>
                {item.date && <span className="flex items-center gap-1"><Clock size={12} />{item.date} {item.time}</span>}
                <span className="flex items-center gap-1"><User size={12} />{item.rollNumber} · {item.branch}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
