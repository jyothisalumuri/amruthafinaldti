import { Phone } from "lucide-react";

type MenuItem = {
  id: number;
  name: string;
  price: number;
  category: "breakfast" | "snacks" | "meals" | "drinks";
};

const menuItems: MenuItem[] = [
  { id: 1, name: "Idli (2 pcs)", price: 20, category: "breakfast" },
  { id: 2, name: "Dosa", price: 30, category: "breakfast" },
  { id: 3, name: "Upma", price: 20, category: "breakfast" },
  { id: 4, name: "Poori (3 pcs)", price: 30, category: "breakfast" },
  { id: 5, name: "Samosa (2 pcs)", price: 20, category: "snacks" },
  { id: 6, name: "Puff", price: 15, category: "snacks" },
  { id: 7, name: "Vada Pav", price: 20, category: "snacks" },
  { id: 8, name: "Biscuit Packet", price: 10, category: "snacks" },
  { id: 9, name: "Meals (Veg)", price: 50, category: "meals" },
  { id: 10, name: "Meals (Non-Veg)", price: 70, category: "meals" },
  { id: 11, name: "Biryani (Veg)", price: 60, category: "meals" },
  { id: 12, name: "Biryani (Chicken)", price: 80, category: "meals" },
  { id: 13, name: "Tea", price: 10, category: "drinks" },
  { id: 14, name: "Coffee", price: 15, category: "drinks" },
  { id: 15, name: "Buttermilk", price: 10, category: "drinks" },
  { id: 16, name: "Juice", price: 25, category: "drinks" },
];

const categories = ["breakfast", "snacks", "meals", "drinks"] as const;
const categoryLabels = { breakfast: "Breakfast", snacks: "Snacks", meals: "Meals", drinks: "Drinks" };

export default function CanteenPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold font-display mb-1">Canteen Menu</h2>
      <p className="text-sm text-muted-foreground mb-2">View the menu and call to place your order.</p>
      <div className="flex items-center gap-2 mb-6">
        <Phone size={14} className="text-primary" />
        <a href="tel:9876543200" className="text-sm font-mono text-primary hover:underline">9876543200</a>
        <span className="text-xs text-muted-foreground">— Canteen Manager (Srinivas)</span>
      </div>

      {categories.map((cat) => (
        <div key={cat} className="mb-6">
          <h3 className="text-sm font-bold font-display uppercase tracking-wider text-muted-foreground mb-2">{categoryLabels[cat]}</h3>
          <div className="border border-border">
            {menuItems
              .filter((item) => item.category === cat)
              .map((item, i) => (
                <div
                  key={item.id}
                  className={`flex items-center justify-between px-4 py-2.5 ${i > 0 ? "border-t border-border" : ""}`}
                >
                  <span className="text-sm">{item.name}</span>
                  <span className="text-sm font-mono font-medium">₹{item.price}</span>
                </div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}
