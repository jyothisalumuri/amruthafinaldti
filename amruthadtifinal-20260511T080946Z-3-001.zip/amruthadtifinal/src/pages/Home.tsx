import { Link } from "react-router-dom";
import { BookOpen, Bus, Calendar, Search, UtensilsCrossed, MessageSquare } from "lucide-react";
import collegeLogo from "@/assets/logo.png";

const modules = [
  { to: "/notes", label: "Notes", icon: BookOpen, desc: "Browse & download academic notes" },
  { to: "/bus-timings", label: "Bus Timings", icon: Bus, desc: "Search bus routes & schedules" },
  { to: "/events", label: "Events", icon: Calendar, desc: "Upcoming college events" },
  { to: "/lost-found", label: "Lost & Found", icon: Search, desc: "Report or find lost items" },
  { to: "/canteen", label: "Canteen Menu", icon: UtensilsCrossed, desc: "View menu & place orders" },
  { to: "/contact", label: "Contact Admin", icon: MessageSquare, desc: "Send queries to administration" },
];

export default function HomePage() {
  return (
    <div className="flex flex-col items-center">
      <img src={collegeLogo} alt="Sri Vasavi Engineering College Logo" className="w-28 h-28 mb-4" />
      <h1 className="text-3xl font-bold font-display text-center tracking-tight">Campus Connect</h1>
      <p className="text-base text-muted-foreground font-mono mt-1 mb-2 text-center">Sri Vasavi Engineering College</p>
      <p className="text-sm text-muted-foreground text-center max-w-md mb-8">
        Your centralized hub for notes, schedules, events, and campus information.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 w-full max-w-3xl">
        {modules.map((mod) => (
          <Link
            key={mod.to}
            to={mod.to}
            className="border border-border bg-card p-5 hover:border-primary transition-colors group"
          >
            <div className="flex items-center gap-3 mb-2">
              <mod.icon size={20} className="text-muted-foreground group-hover:text-primary transition-colors" />
              <span className="font-bold text-sm font-display">{mod.label}</span>
            </div>
            <p className="text-xs text-muted-foreground">{mod.desc}</p>
          </Link>
        ))}
      </div>

      <footer className="mt-12 pt-6 border-t border-border w-full max-w-3xl text-center">
        <p className="text-xs text-muted-foreground font-mono">© 2026 Sri Vasavi Engineering College. All rights reserved.</p>
        <div className="flex justify-center gap-4 mt-2">
          {modules.map((m) => (
            <Link key={m.to} to={m.to} className="text-xs text-muted-foreground hover:text-primary transition-colors">
              {m.label}
            </Link>
          ))}
        </div>
      </footer>
    </div>
  );
}
