import { useState } from "react";
import { Download, FileText, FileSpreadsheet, Presentation, Search } from "lucide-react";

type Note = {
  id: number;
  subject: string;
  branch: string;
  year: string;
  uploadedBy: string;
  fileType: "PDF" | "DOC" | "PPT";
  fileName: string;
};

const BRANCHES = ["All", "CSE", "ECE", "EEE", "Mechanical", "Civil"];
const YEARS = ["All", "1st Year", "2nd Year", "3rd Year", "4th Year"];

const mockNotes: Note[] = [
  { id: 1, subject: "Data Structures", branch: "CSE", year: "2nd Year", uploadedBy: "Dr. Ramesh", fileType: "PDF", fileName: "ds_unit1.pdf" },
  { id: 2, subject: "Digital Electronics", branch: "ECE", year: "2nd Year", uploadedBy: "Prof. Lakshmi", fileType: "PDF", fileName: "de_notes.pdf" },
  { id: 3, subject: "Circuit Theory", branch: "EEE", year: "1st Year", uploadedBy: "Dr. Suresh", fileType: "DOC", fileName: "circuit_theory.docx" },
  { id: 4, subject: "Thermodynamics", branch: "Mechanical", year: "2nd Year", uploadedBy: "Prof. Venkat", fileType: "PPT", fileName: "thermo_ch3.pptx" },
  { id: 5, subject: "Engineering Drawing", branch: "Civil", year: "1st Year", uploadedBy: "Dr. Priya", fileType: "PDF", fileName: "ed_basics.pdf" },
  { id: 6, subject: "Operating Systems", branch: "CSE", year: "3rd Year", uploadedBy: "Prof. Kiran", fileType: "PDF", fileName: "os_unit2.pdf" },
  { id: 7, subject: "DBMS", branch: "CSE", year: "3rd Year", uploadedBy: "Dr. Ramesh", fileType: "DOC", fileName: "dbms_notes.docx" },
  { id: 8, subject: "Signals & Systems", branch: "ECE", year: "3rd Year", uploadedBy: "Prof. Lakshmi", fileType: "PPT", fileName: "signals.pptx" },
];

const fileIcon = (type: string) => {
  switch (type) {
    case "PDF": return <FileText size={16} className="text-destructive" />;
    case "DOC": return <FileSpreadsheet size={16} className="text-primary" />;
    case "PPT": return <Presentation size={16} className="text-muted-foreground" />;
    default: return <FileText size={16} />;
  }
};

function DownloadButton() {
  const [state, setState] = useState<"idle" | "downloading" | "done">("idle");

  const handleDownload = () => {
    setState("downloading");
    setTimeout(() => {
      setState("done");
      setTimeout(() => setState("idle"), 2000);
    }, 1000);
  };

  if (state === "done") {
    return (
      <button className="relative px-4 py-1.5 text-xs font-medium bg-success text-success-foreground overflow-hidden">
        Downloaded
      </button>
    );
  }

  if (state === "downloading") {
    return (
      <button className="relative px-4 py-1.5 text-xs font-medium bg-muted text-foreground overflow-hidden min-w-[100px]">
        <div className="absolute inset-0 bg-primary animate-download-fill" />
        <span className="relative z-10 text-primary-foreground">Downloading...</span>
      </button>
    );
  }

  return (
    <button
      onClick={handleDownload}
      className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
    >
      <Download size={13} />
      Download
    </button>
  );
}

export default function NotesPage() {
  const [search, setSearch] = useState("");
  const [branch, setBranch] = useState("All");
  const [year, setYear] = useState("All");

  const filtered = mockNotes.filter((n) => {
    const matchSearch = n.subject.toLowerCase().includes(search.toLowerCase()) || n.fileName.toLowerCase().includes(search.toLowerCase());
    const matchBranch = branch === "All" || n.branch === branch;
    const matchYear = year === "All" || n.year === year;
    return matchSearch && matchBranch && matchYear;
  });

  return (
    <div>
      <h2 className="text-2xl font-bold font-display mb-1">Notes</h2>
      <p className="text-sm text-muted-foreground mb-6">Browse and download academic notes by branch, year, and subject.</p>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search notes by subject..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm bg-card border border-border focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <select
          value={branch}
          onChange={(e) => setBranch(e.target.value)}
          className="px-3 py-2 text-sm bg-card border border-border focus:outline-none focus:ring-1 focus:ring-primary"
        >
          {BRANCHES.map((b) => <option key={b}>{b}</option>)}
        </select>
        <select
          value={year}
          onChange={(e) => setYear(e.target.value)}
          className="px-3 py-2 text-sm bg-card border border-border focus:outline-none focus:ring-1 focus:ring-primary"
        >
          {YEARS.map((y) => <option key={y}>{y}</option>)}
        </select>
      </div>

      {/* Notes table */}
      <div className="border border-border">
        {/* Header */}
        <div className="hidden sm:grid grid-cols-[1fr_100px_80px_80px_100px_110px] gap-2 px-4 py-2.5 bg-card text-xs font-medium text-muted-foreground uppercase tracking-wide font-mono">
          <span>Subject</span>
          <span>Branch</span>
          <span>Year</span>
          <span>Type</span>
          <span>Uploaded By</span>
          <span></span>
        </div>
        {filtered.length === 0 && (
          <div className="px-4 py-8 text-center text-sm text-muted-foreground">No notes found matching your criteria.</div>
        )}
        {filtered.map((note) => (
          <div
            key={note.id}
            className="grid grid-cols-1 sm:grid-cols-[1fr_100px_80px_80px_100px_110px] gap-1 sm:gap-2 px-4 py-3 border-t border-border items-center"
          >
            <div className="font-medium text-sm">{note.subject}</div>
            <div className="text-xs font-mono text-muted-foreground sm:text-foreground">{note.branch}</div>
            <div className="text-xs font-mono text-muted-foreground">{note.year}</div>
            <div className="flex items-center gap-1 text-xs font-mono">
              {fileIcon(note.fileType)}
              {note.fileType}
            </div>
            <div className="text-xs text-muted-foreground truncate">{note.uploadedBy}</div>
            <div>
              <DownloadButton />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
