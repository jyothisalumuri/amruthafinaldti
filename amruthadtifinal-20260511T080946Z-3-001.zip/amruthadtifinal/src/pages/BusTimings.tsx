import { useState } from "react";
import { Search, Phone, Bus } from "lucide-react";

type BusRoute = {
  id: number;
  route: string;
  busNumber: string;
  departure: string;
  driver: string;
  contact: string;
};

const mockRoutes: BusRoute[] = [
  { id: 1, route: "Tadepalligudem → College", busNumber: "SV-01", departure: "07:30 AM", driver: "Raju", contact: "9876543210" },
  { id: 2, route: "Eluru → College", busNumber: "SV-02", departure: "07:15 AM", driver: "Suresh", contact: "9876543211" },
  { id: 3, route: "Bhimavaram → College", busNumber: "SV-03", departure: "07:00 AM", driver: "Venkat", contact: "9876543212" },
  { id: 4, route: "Nidadavolu → College", busNumber: "SV-04", departure: "07:45 AM", driver: "Krishna", contact: "9876543213" },
  { id: 5, route: "Tanuku → College", busNumber: "SV-05", departure: "07:20 AM", driver: "Ramesh", contact: "9876543214" },
  { id: 6, route: "College → Tadepalligudem", busNumber: "SV-01", departure: "04:30 PM", driver: "Raju", contact: "9876543210" },
  { id: 7, route: "College → Eluru", busNumber: "SV-02", departure: "04:30 PM", driver: "Suresh", contact: "9876543211" },
  { id: 8, route: "College → Bhimavaram", busNumber: "SV-03", departure: "04:30 PM", driver: "Venkat", contact: "9876543212" },
];

export default function BusTimingsPage() {
  const [search, setSearch] = useState("");

  const filtered = mockRoutes.filter(
    (r) =>
      r.route.toLowerCase().includes(search.toLowerCase()) ||
      r.busNumber.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <h2 className="text-2xl font-bold font-display mb-1">Bus Timings</h2>
      <p className="text-sm text-muted-foreground mb-6">Search your route to find bus schedules and driver contact info.</p>

      <div className="relative mb-6 max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search by route or bus number..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 text-sm bg-card border border-border focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div className="border border-border">
        <div className="hidden sm:grid grid-cols-[1fr_90px_100px_100px_120px] gap-2 px-4 py-2.5 bg-card text-xs font-medium text-muted-foreground uppercase tracking-wide font-mono">
          <span>Route</span>
          <span>Bus No.</span>
          <span>Departure</span>
          <span>Driver</span>
          <span>Contact</span>
        </div>
        {filtered.length === 0 && (
          <div className="px-4 py-8 text-center text-sm text-muted-foreground">No routes found.</div>
        )}
        {filtered.map((route) => (
          <div
            key={route.id}
            className="grid grid-cols-1 sm:grid-cols-[1fr_90px_100px_100px_120px] gap-1 sm:gap-2 px-4 py-3 border-t border-border items-center"
          >
            <div className="flex items-center gap-2 font-medium text-sm">
              <Bus size={15} className="text-muted-foreground shrink-0" />
              {route.route}
            </div>
            <div className="text-xs font-mono">{route.busNumber}</div>
            <div className="text-xs font-mono font-medium">{route.departure}</div>
            <div className="text-xs text-muted-foreground">{route.driver}</div>
            <a
              href={`tel:${route.contact}`}
              className="flex items-center gap-1 text-xs font-mono text-primary hover:underline"
            >
              <Phone size={12} />
              {route.contact}
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
